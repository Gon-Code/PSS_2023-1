typedef unsigned int uint;

uint comprimir(uint *a, int nbits);

